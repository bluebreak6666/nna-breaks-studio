export const mlbAmerican = ['巴爾的摩金鶯','波士頓紅襪','紐約洋基','坦帕灣光芒','多倫多藍鳥','芝加哥白襪','克里夫蘭守護者','底特律老虎','堪薩斯市皇家','明尼蘇達雙城','運動家','休士頓太空人','洛杉磯天使','西雅圖水手','德州遊騎兵'];
export const mlbNational = ['亞特蘭大勇士','邁阿密馬林魚','紐約大都會','費城費城人','華盛頓國民','芝加哥小熊','辛辛那提紅人','密爾瓦基釀酒人','匹茲堡海盜','聖路易紅雀','亞利桑那響尾蛇','科羅拉多洛磯','洛杉磯道奇','聖地牙哥教士','舊金山巨人'];
export const mlb = [...mlbAmerican, ...mlbNational];
export function listLines(text:string){return text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean)}
export function duplicateItems(text:string){const counts=new Map<string,number>();for(const x of listLines(text))counts.set(x,(counts.get(x)||0)+1);return [...counts].filter(([,count])=>count>1)}
export type SavedList={name:string;text:string};
export function validSavedLists(value:unknown):SavedList[]{if(!Array.isArray(value))return [];return value.filter((x):x is SavedList=>!!x&&typeof x.name==='string'&&x.name.length>0&&x.name.length<=30&&typeof x.text==='string'&&x.text.length<=20000&&listLines(x.text).length>0&&listLines(x.text).length<=100).slice(0,5)}
