export type Setup={names:string[];teamText:string;title:string;linkNames:boolean;fillMode:'none'|'blank'|'value';fillValue:string;volume:number};
export type SavedList={name:string;text:string};
export type SetupBackup={format:'break-room-setup';version:1;createdAt:string;source:string;setup:Setup;savedLists:SavedList[]};
export const MAX_BACKUP_BYTES=256*1024;
function text(v:unknown,max:number):v is string{return typeof v==='string'&&v.length<=max}
function lines(v:string){return v.split(/\r?\n/).map(x=>x.trim()).filter(Boolean)}
export function parseSetupBackup(raw:string):SetupBackup{
 if(new TextEncoder().encode(raw).length>MAX_BACKUP_BYTES)throw Error('備份檔不可超過 256 KB。');
 let d:any;try{d=JSON.parse(raw.replace(/^\uFEFF/,''))}catch{throw Error('無法讀取 JSON，請選擇本工具匯出的設定備份。')}
 if(!d||d.format!=='break-room-setup'||d.version!==1)throw Error('不支援此備份格式或版本。');
 const s=d.setup;
 if(!text(d.createdAt,50)||!Number.isFinite(Date.parse(d.createdAt))||!text(d.source,80)||!s||!Array.isArray(s.names)||s.names.length>100||!s.names.every((x:unknown)=>text(x,200)&&x.trim().length>0)||!text(s.teamText,20000)||lines(s.teamText).length>100||!text(s.title,55)||typeof s.linkNames!=='boolean'||!['none','blank','value'].includes(s.fillMode)||!text(s.fillValue,80)||/[\r\n]/.test(s.fillValue)||!Number.isFinite(s.volume)||s.volume<0||s.volume>100)throw Error('設定內容不完整或超出限制（最多 100 名額／項目）。');
 if(!Array.isArray(d.savedLists)||d.savedLists.length>5||!d.savedLists.every((x:any)=>x&&text(x.name,30)&&x.name.trim().length>0&&text(x.text,20000)&&lines(x.text).length>0&&lines(x.text).length<=100)||new Set(d.savedLists.map((x:any)=>x.name)).size!==d.savedLists.length)throw Error('常用清單格式錯誤或超過 5 份。');
 return {format:'break-room-setup',version:1,createdAt:d.createdAt,source:d.source,setup:{names:[...s.names],teamText:s.teamText,title:s.title,linkNames:s.linkNames,fillMode:s.fillMode,fillValue:s.fillValue,volume:s.volume},savedLists:d.savedLists.map((x:SavedList)=>({name:x.name,text:x.text}))};
}
export function createSetupBackup(setup:Setup,savedLists:unknown,source:string){return parseSetupBackup(JSON.stringify({format:'break-room-setup',version:1,createdAt:new Date().toISOString(),source,setup,savedLists}))}
