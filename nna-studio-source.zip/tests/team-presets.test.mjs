import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import ts from 'typescript';
import {test} from 'node:test';
const code=ts.transpileModule(readFileSync(new URL('../lib/team-presets.ts',import.meta.url),'utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
const {mlb,mlbAmerican,mlbNational,duplicateItems,validSavedLists}=await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));
test('MLB has 30 unique clubs and disjoint 15-team leagues',()=>{assert.equal(mlb.length,30);assert.equal(new Set(mlb).size,30);assert.equal(mlbAmerican.length,15);assert.equal(mlbNational.length,15);assert.ok(mlb.includes('運動家'));assert.ok(mlb.includes('克里夫蘭守護者'));assert.ok(mlbNational.includes('洛杉磯道奇'));assert.ok(mlbAmerican.includes('紐約洋基'))});
test('duplicate warning handles whitespace and keeps repeated slots',()=>{assert.deepEqual(duplicateItems(' 洋基 \r\n道奇\n洋基\n\n'),[['洋基',2]])});
test('stored lists reject malformed or oversized values',()=>{assert.deepEqual(validSavedLists(null),[]);assert.deepEqual(validSavedLists([null,{name:'a',text:5},{name:'a',text:'\n'},{name:'a',text:Array(101).fill('x').join('\n')},{name:'a',text:'x'.repeat(20001)}]),[]);assert.deepEqual(validSavedLists([{name:'雙名額',text:'A\nA'}]),[{name:'雙名額',text:'A\nA'}]);assert.equal(validSavedLists(Array(6).fill({name:'a',text:'b'})).length,5)});
